/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  ActivityIndicator,
  Dimensions,
  SafeAreaView,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Linking,
} from 'react-native';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import QRCode from 'react-native-qrcode-svg';
import Buttons from '../../uiElements/Buttons/RoundButtons';

const imageWidth = Dimensions.get('window').width;
import NavBar from '../../uiElements/NavBar';

//import Loading from '../../../uiElements/Loading';

import styles from './styles';

// const imageWidth = Dimensions.get('window').width;
class Search extends Component {
  fieldRef = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      isLogged: false,
      visible: true,
    };
  }

  // static getDerivedStateFromProps(props, state) {

  // }

  render() {
    return (
      <SafeAreaView style={{flex: 1}}>
        <NavBar
          name={'About Us'}
          onPressBurger={() => this.props.navigation.openDrawer()}
        />
        <View style={{flex: 1, alignItems: 'center'}}>
          {/* <QRCode
      value="http://awesome.link.qr"
      size={200}
      logoBackgroundColor='transparent'
    /> */}

          <View style={{margin: wp('5%')}} />
          <View style={{margin: wp('5%')}}>
            <Text>
              Evolution Hospitality Institute (RTO# 91256), A name that in the
              business of training hospitality and education has set itself up
              as a leader.
            </Text>
            <View style={{margin: wp('5%')}} />
            <Text>
              The Institute has received four national and state awards
              throughout its lifespan. The institute has taken on displaced and
              disadvantaged students and helped them to complete their training
              with its links to Evolution Employment Network.
            </Text>
            <View style={{margin: wp('5%')}} />
            <Text>For more information</Text>
          </View>
          <View style={{alignItems: 'center', paddingTop: wp('10%')}}>
            <Buttons
              text="View Our Website"
              btnfontSize={wp('5%')}
              btnbackgroundColor="#841c7c"
              btntxtncolor="#ffffff"
              btnMarginRight={imageWidth / 20}
              btnMarginLeft={imageWidth / 20}
              onPress={() => {
                Linking.openURL('https://www.evolution.edu.au/all-courses/');
              }}
            />
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

// const mapStateToProps = state =>({
//   loginsuccessEmail:state.startUpReducer.loginsuccessEmail,
//   loading:state.startUpReducer.loading,
//   accesstoken:state.startUpReducer.accesstoken

// });

export default Search;
