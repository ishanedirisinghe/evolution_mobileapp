/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
//components




class NavBarDefault extends React.Component {

    route = () => {
        const { onPress } = this.props;
        onPress();
    }

    onPressBack = () => {
        const { onPressBack } = this.props;
        onPressBack();
    }

    render() {
        return (
            <View style={styles.navbar}>
                <View style={{alignSelf:'center',flexDirection:'row',paddingLeft:wp('4%')}}>
                <Icon name="md-arrow-back" size={30} color='#fff'  onPress={()=>this.onPressBack()}/> 
                <View style={{paddingLeft:wp('5%')}}>
                         <Text style={{  fontSize: wp('5.6%'),alignSelf:'center',color:'#fff' }}>{this.props.name}</Text>
                    </View>
                </View>
               
              
             
            
                    
                  
                    <View style={{flex:1,alignSelf:'center'}}>
                         
                    </View>
                  
                  
                    
                    {/* <Icon 
                                name='filter'
                                size={wp('5%')}
                                color='black'
                                onPress={()=>this.onPressStar()}
                                style={{
                                   marginRight: wp('5%'),
                                }} 
                          />
                 */}

                    {/* <TouchableOpacity onPress={() => this.route()}>
                        <Image
                            style={{ width: 20, height: 20, marginRight: 10,marginBottom:5,}}
                            source={require('../../images/arrow.png')}
                        />
                    </TouchableOpacity> */}
                </View>
           
        );
    }
}

const styles = {
    navbar: {
       
        height:(wp('15%')),
        flexDirection:'row',
        backgroundColor: '#777',
        elevation: 0,
        alignContent: 'center',
    }
}

export default NavBarDefault;
