/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
import React, {Component} from 'react';
import DeviceInfo from 'react-native-device-info';
import {
  View,
  Text,
  Image,
  Dimensions,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  ImageBackground,
} from 'react-native';
import FlashMessage from 'react-native-flash-message';
import {showMessage, hideMessage} from 'react-native-flash-message';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
//import Icon from 'react-native-vector-icons/MaterialIcons';
import Spinner from 'react-native-loading-spinner-overlay';

const imageHeight = Dimensions.get('window').height;
const imageWidth = Dimensions.get('window').width;
import styles from './styles';
import Buttons from '../../uiElements/Buttons/RoundButtons';
import DefaultPreference from 'react-native-default-preference';

// const imageWidth = Dimensions.get('window').width;
class PasscodeLogin extends Component {
  fieldRef = React.createRef();
  constructor(props) {
    super(props);
    this.state = {
      loginsignupstate: 1,
      password: '',
      //password_confirm: '',
      spinner: false,
    };
  }

  async onPressPasswordReset() {
    console.log('DEBUG: Reset Passcode.');
    let {password} = this.state;
    console.log(
      'Password:',
      password,
      //' - Confirm Passcode:',
      //password_confirm,
    );
    var navigation = this.props.navigation;
    // eslint-disable-next-line consistent-this
    var context = this;
    // eslint-disable-next-line eqeqeq
    if (!password || password.trim() == '') {
      console.log('DEBUG: Reset Passcode.');
      showMessage({
        message: 'Passcode',
        description: 'Please enter the passcode.',
        type: 'danger',
      });
      return;
    }

    console.log('Debug: Get user_data in reset Passcode');
    DefaultPreference.get('user_data').then(function(user_data) {
      var jsonUserData = JSON.parse(user_data);
      let devId = DeviceInfo.getUniqueId();

      console.log(
        'Debug: Get user_data in reset Passcode done',
        jsonUserData,
        'dev id:',
        devId,
      );
      let requestPathStdInfo =
        global.API_ENDPOINT +
        '/api/AccountAPI/Login?' +
        'passcode=' +
        password.trim() +
        '&DeviceID=' +
        devId;
      //let requestPathStdInfo='https://reqres.in/api/users?page=2&UserID='+jsonUserData.ID+'&passcode='+password.trim()+'&DeviceID='+devId
      console.log('DEBUG: Passcodelogin', requestPathStdInfo);
      context.setState({spinner: true});
      fetch(requestPathStdInfo, {
        method: 'GET',
      })
        .then(stdInfoResponse => stdInfoResponse.text())
        .then(stdInfoResponseTxt => {
          context.setState({spinner: false});
          // stdInfoResponseTxt='{ "ImageUrl": "sdsdsd", "IsPassWordReset": true, "ID": "0bf2fb0e-64fb-4d56-a36e-2b14d3bd65d2", "StudentID": "123123", "Name": "abcd", "Address": "100, adadad Rd", "Phone": "0774837837", "EnteredBy": "00000000-0000-0000-0000-000000000000", "EnteredOn": "0001-01-01T00:00:00", "eMail": "abcd@efb.lk", "StudentImageUploads": [], "AspNetUser": null }'
          console.log('DEBUG: Passcode login success. ', stdInfoResponseTxt);
          let jsonPasrsedData = JSON.parse(stdInfoResponseTxt);
          // eslint-disable-next-line eqeqeq
          if (jsonPasrsedData && jsonPasrsedData.Message == undefined) {
            global.session = jsonPasrsedData;
            navigation.navigate('MyIdScreen', {
              user_data: false,
            });
          } else {
            showMessage({
              message: 'Invalid Passcode',
              description: 'Please enter a valid passcode for this device.',
              type: 'danger',
            });
          }
        })
        .catch(error => {
          context.setState({spinner: false});
          console.log('DEBUG:  Password reset request failed.', error);
          showMessage({
            message: 'Error',
            description:
              'Unknown server error. Please check your internet connection. Contact support if issue prevails.',
            type: 'danger',
          });
        });
    });
  }
  changeLoginSignUpState() {
    // eslint-disable-next-line eqeqeq
    if (this.state.loginsignupstate == 1) {
      this.setState({loginsignupstate: 2});
    } else {
      this.setState({loginsignupstate: 1});
    }
  }

  render() {
    return (
      <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null}
                style={{ flex: 1 }} >					 
      <SafeAreaView style={{flex: 1}}>
        <Spinner visible={this.state.spinner} textContent={'Loading...'} />
        <ScrollView>
          <ImageBackground
            style={{height: wp('70%'), width: wp('100%'), marginTop: -wp('7%')}}
            source={require('../../../images/top_bg_purple.png')}>
            <View style={{alignItems: 'center', marginTop: wp('15%')}}>
              <Text
                style={{
                  fontSize: wp('10%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Evolution Australia
              </Text>
              <Text
                style={{
                  fontSize: wp('8%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Login with Passcode
              </Text>
            </View>
          </ImageBackground>

          {/* main view */}
          <View style={{marginLeft: wp('5%'), marginRight: wp('5%')}}>
            <View
              style={{
                marginTop: wp('5%'),
                marginBottom: wp('5%'),
                alignItems: 'center',
              }}>
              <Text>Please enter your passcode for easy login</Text>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                Passcode
              </Text>
              <View style={styles.email}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon2.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => this.setState({password: text})}
                  inlineImageLeft="username"
                  inlineImagePadding={2}
                  keyboardType="numeric"
                  secureTextEntry={true}
                />
              </View>
            </View>
          </View>

          <View style={{alignItems: 'center', paddingTop: wp('10%')}}>
            <Buttons
              text="Login"
              btnfontSize={wp('5%')}
              btnbackgroundColor="#841c7c"
              btntxtncolor="#ffffff"
              btnMarginRight={imageWidth / 20}
              btnMarginLeft={imageWidth / 20}
              onPress={this.onPressPasswordReset.bind(this)}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
      </KeyboardAvoidingView>			 
    );
  }
}

export default PasscodeLogin;
