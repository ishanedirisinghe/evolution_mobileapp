/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eqeqeq */
/* eslint-disable consistent-this */
/* eslint-disable react/jsx-no-duplicate-props */
/* eslint-disable no-undef */
import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  Dimensions,
  SafeAreaView,
  ScrollView,
  TextInput,
  ImageBackground,
  KeyboardAvoidingView,		   
} from 'react-native';

import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
//import Icon from 'react-native-vector-icons/MaterialIcons';
import DefaultPreference from 'react-native-default-preference';
const imageWidth = Dimensions.get('window').width;
import styles from './styles';
import Buttons from '../../uiElements/Buttons/RoundButtons';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
var re = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
// const imageWidth = Dimensions.get('window').width;
class ResetPassword extends Component {
  fieldRef = React.createRef();
  constructor(props) {
    super(props);
    this.state = {
      loginsignupstate: 1,
      password: '',
      password_confirm: '',
      spinner: false,
    };
  }

  async onPressPasswordReset() {
    var context = this;
    console.log('DEBUG: Reset password.');
    let {password, password_confirm} = this.state;
    console.log(
      'Password:',
      password,
      ' - Confirm Password:',
      password_confirm,
    );
    var navigation = this.props.navigation;
    if (!password || password.trim() == '') {
      console.log('DEBUG: Reset password2.');
      showMessage({
        message: 'New Password',
        description: 'Please enter the new password.',
        type: 'danger',
      });
      return;
    } else if (!password_confirm || password_confirm.trim() == '') {
      showMessage({
        message: 'Confirm Password',
        description: 'Please enter the confirm password.',
        type: 'danger',
      });
      return;
    } else if (password.trim() != password_confirm.trim()) {
      showMessage({
        message: 'Passwords',
        description: "'New Password' and 'Confirm Password' does not match.",
        type: 'danger',
      });
      return;
    } else if (!re.test(password.trim())) {
      console.log(re.test(password.trim()));
      showMessage({
        message: 'Passwords',
        description:
          'Password must have Minimum six characters, at least one uppercase letter, one lowercase letter, one number and one special character:',
        type: 'danger',
      });
      return;
    }

    console.log('Debug: Get user_data in reset password');
    DefaultPreference.get('user_data').then(function(user_data) {
      var jsonUserData = JSON.parse(user_data);
      console.log('Debug: Get user_data in reset password done', jsonUserData);
      let requestPathStdInfo =
        global.API_ENDPOINT +
        '/api/StudentAPI/ResetPassword?UserID=' +
        jsonUserData.ID +
        '&password=' +
        password_confirm.trim();
      console.log('DEBUG: GetStudentInfo', requestPathStdInfo);
      context.setState({spinner: true});
      fetch(requestPathStdInfo, {
        method: 'GET',
        headers: {
          Authorization: 'Bearer ' + global.session.access_token,
        },
      })
        .then(stdInfoResponse => stdInfoResponse.text())
        .then(stdInfoResponseTxt => {
          context.setState({spinner: false});
          console.log('DEBUG: Password reset success. ', stdInfoResponseTxt);
          jsonUserData.passwordResetComplte = true;
          DefaultPreference.set('user_data', JSON.stringify(jsonUserData)).then(
            function() {
              console.log('DEBUG: user_data Updated to .', jsonUserData);
              navigation.navigate('Passcode');
            },
          );
        })
        .catch(error => {
          context.setState({spinner: false});
          console.log('DEBUG:  Password reset request failed.', error);
          showMessage({
            message: 'Error',
            description:
              'Unknown server error. Please check your internet connection. Contact support if issue prevails.',
            type: 'danger',
          });
        });
    });
  }

  changeLoginSignUpState() {
    if (this.state.loginsignupstate == 1) {
      this.setState({loginsignupstate: 2});
    } else {
      this.setState({loginsignupstate: 1});
    }
  }

  render() {
    return (
      <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null}
                style={{ flex: 1 }} >						 
      <SafeAreaView style={{flex: 1}}>
        <Spinner visible={this.state.spinner} textContent={'Loading...'} />
        <ScrollView>
          <ImageBackground
            style={{height: wp('70%'), width: wp('100%'), marginTop: -wp('7%')}}
            source={require('../../../images/top_bg_purple.png')}>
            <View style={{alignItems: 'center', marginTop: wp('15%')}}>
              <Text
                style={{
                  fontSize: wp('10%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Evolution Australia
              </Text>
              <Text
                style={{
                  fontSize: wp('8%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Reset Password
              </Text>
            </View>
          </ImageBackground>

          {/* main view */}
          <View style={{marginLeft: wp('5%'), marginRight: wp('5%')}}>
            <View
              style={{
                marginTop: wp('5%'),
                marginBottom: wp('5%'),
                alignItems: 'center',
              }}>
              <Text style={{color: '#841c7c'}}>Please reset your password</Text>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                New Password
              </Text>
              <View style={styles.email}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon2.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => onChangeText(text)}
                  onChangeText={text => this.setState({password: text})}
                  inlineImageLeft="username"
                  secureTextEntry={true}
                  inlineImagePadding={2}
                />
              </View>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                Confirm Password
              </Text>
              <View style={styles.password}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon2.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => this.setState({password_confirm: text})}
                  inlineImageLeft="username"
                  secureTextEntry={true}
                  inlineImagePadding={2}
                />
              </View>
            </View>

            <View style={{alignItems: 'center', paddingTop: wp('10%')}}>
              <Buttons
                text="Reset Password"
                btnfontSize={wp('5%')}
                btnbackgroundColor="#841c7c"
                btntxtncolor="#ffffff"
                btnMarginRight={imageWidth / 20}
                btnMarginLeft={imageWidth / 20}
                onPress={this.onPressPasswordReset.bind(this)}
              />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
      </KeyboardAvoidingView>		 
    );
  }
}

export default ResetPassword;
