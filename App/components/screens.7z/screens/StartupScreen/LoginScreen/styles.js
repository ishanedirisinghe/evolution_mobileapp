
import EStyleSheet from 'react-native-extended-stylesheet';
import {Dimensions} from 'react-native';
const imageWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: imageWidth / 380});
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';


export default EStyleSheet.create({
  container:{
       
 
  },
     
    textStyle:{
   
        justifyContent:'flex-start',
        paddingLeft:wp('5%')

  },
  numberStyles:{
    width:wp('10%'),
    height:wp('10%'),
    borderRadius:wp('10%'),
    backgroundColor:'#000',
    alignItems:'center',
    justifyContent:'center'
   
       

  },
  dot:{
  color:'#fff',
  width:wp('4%'),
  height:wp('4%'),
  backgroundColor:'#777777',
  borderRadius:wp('5%'),
  marginLeft:wp('3%')
},
dotlight:{
 
    color:'#fff',
    width:wp('4%'),
    height:wp('4%'),
    backgroundColor:'white',
    borderRadius:wp('5%'),
    marginLeft:wp('3%')

},
email: {
    
  flexDirection: 'row',

  alignItems: 'center',
  
  borderBottomWidth: 1,
  borderColor: '#841c7c',
  height: 40,
  borderRadius: 5 ,
  
},
password:{
  flexDirection: 'row',

  alignItems: 'center',
 
  borderBottomWidth: 1,
  borderColor: '#841c7c',
  height: 40,
  borderRadius: 5 ,
}
 

  
}); 