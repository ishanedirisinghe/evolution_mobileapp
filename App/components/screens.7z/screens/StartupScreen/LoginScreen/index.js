/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eqeqeq */
/* eslint-disable consistent-this */
/* eslint-disable no-undef */
import React, {Component} from 'react';
import DefaultPreference from 'react-native-default-preference';

import {
  View,
  Text,
  Image,
  Dimensions,
  SafeAreaView,
  ScrollView,
  TextInput,
  ImageBackground,
  KeyboardAvoidingView, 
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
// eslint-disable-next-line prettier/prettier
import {
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
//import Icon from 'react-native-vector-icons/MaterialIcons';
import Spinner from 'react-native-loading-spinner-overlay';

const imageWidth = Dimensions.get('window').width;
import styles from './styles';
import Buttons from '../../uiElements/Buttons/RoundButtons';

// const imageWidth = Dimensions.get('window').width;
class LoginSignup extends Component {
  fieldRef = React.createRef();
  constructor(props) {
    super(props);
    this.state = {
      loginsignupstate: 1,
      username: '', //'venura@multifinance.lk',
      password: '', //'User@1234',
      spinner: false,
    };
  }

  async onPressLogin() {
    var context = this;
    let {username, password} = this.state;
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let validEmail = re.test(String(username).toLowerCase());
    if (!username || username.trim() == '' || !validEmail) {
      showMessage({
        message: 'Email',
        description: 'Please enter a valid email.',
        type: 'danger',
      });
      return;
    } else if (!password || password.trim() == '') {
      showMessage({
        message: 'Password',
        description: 'Please enter a password.',
        type: 'danger',
      });
      return;
    }
    let data = {
      grant_type: 'password',
      userName: username.trim(), //'admin@evolution.edu.au',//username,
      password: password.trim(), //'Admin@123',//password
    };
    let requestPath = global.API_ENDPOINT + '/token';
    var navigation = this.props.navigation;
    const searchParams = Object.keys(data)
      .map(key => {
        return encodeURIComponent(key) + '=' + encodeURIComponent(data[key]);
      })
      .join('&');
    console.log('DEBUG: Sending token request.', requestPath, data);
    context.setState({spinner: true});
    fetch(requestPath, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      },
      body: searchParams,
    })
      .then(response => response.text())
      .then(result => {
        context.setState({spinner: false});
        let resultJson = JSON.parse(result);
        if (resultJson.access_token != undefined) {
          global.session = resultJson;
          console.log('DEBUG: Token request success.', resultJson);
          let requestPathStdInfo =
            global.API_ENDPOINT + '/api/StudentAPI/GetStudentInfo';
          console.log('DEBUG: GetStudentInfo', requestPathStdInfo);
          fetch(requestPathStdInfo, {
            method: 'GET',
            headers: {
              Authorization: 'Bearer ' + global.session.access_token,
            },
          })
            .then(stdInfoResponse => stdInfoResponse.text())
            .then(stdInfoResponseTxt => {
              console.log(
                'DEBUG: GetStudentInfo request success. ',
                stdInfoResponseTxt,
              );
              console.log('DEBUG: 2222222222222222 ');
              DefaultPreference.set('user_data', stdInfoResponseTxt).then(
                function() {
                  console.log('DEBUG: 333333333333333');
                  console.log('DEBUG: 44444444444', stdInfoResponseTxt);
                  resultJsonStdInfo = JSON.parse(stdInfoResponseTxt);
                  // resultJsonStdInfo['IsPassWordReset']=true;
                  if (!resultJsonStdInfo.IsPassWordReset) {
                    navigation.navigate('ResetPassword');
                  } else {
                    navigation.navigate('PasscodeLogin');
                  }
                },
              );
            })
            .catch(error => {
              context.setState({spinner: false});
              console.log('DEBUG: GetStudentInfo request failed.', error);
              showMessage({
                message: 'Error',
                description:
                  'Unknown server error. Please check your internet connection. Contact support if issue prevails.',
                type: 'danger',
              });
            });
        } else {
          context.setState({spinner: false});
          showMessage({
            message: 'Login failed',
            description: 'The user name or password is incorrect',
            type: 'danger',
          });
          console.log(
            'DEBUG: Token request failed, invalid credentials.',
            resultJson,
          );
        }
      })
      .catch(error => {
        console.log('DEBUG: Token request failed.', error);
        context.setState({spinner: false});
        showMessage({
          message: 'Login failed',
          description:
            'Unknown server error. Please check your internet connection. Contact support if issue prevails.',
          type: 'danger',
        });
      });
  }

  changeLoginSignUpState() {
    if (this.state.loginsignupstate == 1) {
      this.setState({loginsignupstate: 2});
    } else {
      this.setState({loginsignupstate: 1});
    }
  }

  render() {
    return (
      <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null}
                style={{ flex: 1 }} >						 
      <SafeAreaView style={{flex: 1}}>
        <Spinner visible={this.state.spinner} textContent={'Loading...'} />

        <ScrollView>
          <ImageBackground
            style={{height: wp('70%'), width: wp('100%'), marginTop: -wp('7%')}}
            source={require('../../../images/top_bg_purple.png')}>
            <View style={{alignItems: 'center', marginTop: wp('15%')}}>
              <Text
                style={{
                  fontSize: wp('10%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Evolution Australia
              </Text>
              <Text
                style={{
                  fontSize: wp('8%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                User Login
              </Text>
            </View>
          </ImageBackground>

          {/* main view */}
          <View style={{marginLeft: wp('5%'), marginRight: wp('5%')}}>
            <View style={{marginTop: wp('5%'), alignItems: 'center'}}>
              <Text>
                Please enter user name and password sent you via email
              </Text>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                Email
              </Text>
              <View style={styles.email}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon1.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => this.setState({username: text})}
                  inlineImageLeft="username"
                  inlineImagePadding={2}
                />
              </View>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                Password
              </Text>
              <View style={styles.password}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon2.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => this.setState({password: text})}
                  inlineImageLeft="username"
                  secureTextEntry={true}
                  inlineImagePadding={2}
                  onShow={() => {
                    this.textInput.focus();
                  }}
                />
              </View>
            </View>

            <View style={{alignItems: 'center', paddingTop: wp('10%')}}>
              <Buttons
                text="Login"
                btnfontSize={wp('5%')}
                btnbackgroundColor="#841c7c"
                btntxtncolor="#ffffff"
                btnMarginRight={imageWidth / 20}
                btnMarginLeft={imageWidth / 20}
                onPress={this.onPressLogin.bind(this)}
              />
            </View>

            {/* <View style={{alignItems:'center',paddingTop:wp('5%'),paddingBottom:wp('5%')}}>
              <Text style={{color:'#ff5d05',fontSize:wp('5%')}}>Sign Up</Text>
            </View> */}
          </View>
        </ScrollView>
      </SafeAreaView>
      </KeyboardAvoidingView>			 
    );
  }
}

export default LoginSignup;
