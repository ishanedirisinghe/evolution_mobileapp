/* eslint-disable eqeqeq */
/* eslint-disable consistent-this */
/* eslint-disable react-native/no-inline-styles */
import React, {Component} from 'react';
import DeviceInfo from 'react-native-device-info';
import {
  View,
  Text,
  Image,
  Dimensions,
  SafeAreaView,
  ScrollView,
  TextInput,
  ImageBackground,
  KeyboardAvoidingView,		   
} from 'react-native';
import {showMessage} from 'react-native-flash-message';
import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
//import Icon from 'react-native-vector-icons/MaterialIcons';

import Spinner from 'react-native-loading-spinner-overlay';
const imageWidth = Dimensions.get('window').width;
import styles from './styles';
import Buttons from '../../uiElements/Buttons/RoundButtons';
import DefaultPreference from 'react-native-default-preference';

// const imageWidth = Dimensions.get('window').width;
class LoginSignup extends Component {
  fieldRef = React.createRef();
  constructor(props) {
    super(props);
    this.state = {
      loginsignupstate: 1,
      password: '',
      password_confirm: '',
    };
  }

  async onPressPasswordReset() {
    var context = this;
    console.log('DEBUG: Reset Passcode.');
    let {password, password_confirm} = this.state;
    console.log(
      'Password:',
      password,
      ' - Confirm Passcode:',
      password_confirm,
    );
    var navigation = this.props.navigation;
    if (!password || password.trim() == '') {
      console.log('DEBUG: Reset Passcode.');
      showMessage({
        message: 'New Passcode',
        description: 'Please enter the new passcode.',
        type: 'danger',
      });
      return;
    } else if (!password_confirm || password_confirm.trim() == '') {
      showMessage({
        message: 'Confirm Passcode',
        description: 'Please enter the confirm passcode.',
        type: 'danger',
      });
      return;
    } else if (password.trim() != password_confirm.trim()) {
      showMessage({
        message: 'Passwords',
        description: "'New Passcode' and 'Confirm Passcode' does not match.",
        type: 'danger',
      });
      return;
    } else if (password.length < 6) {
      showMessage({
        message: 'Passwords',
        description: 'Minumum 6 Digits',
        type: 'danger',
      });
      return;
    }
    console.log('Debug: Get user_data in reset Passcode');
    DefaultPreference.get('user_data').then(function(user_data) {
      var jsonUserData = JSON.parse(user_data);
      let devId = DeviceInfo.getUniqueId();

      console.log(
        'Debug: Get user_data in reset Passcode done',
        jsonUserData,
        'dev id:',
        devId,
      );
      let requestPathStdInfo =
        global.API_ENDPOINT +
        '/api/StudentAPI/SetPassCode?UserID=' +
        jsonUserData.ID +
        '&passcode=' +
        password_confirm.trim() +
        '&DeviceID=' +
        devId;
      console.log('DEBUG: GetStudentInfo', requestPathStdInfo);
      context.setState({spinner: true});
      fetch(requestPathStdInfo, {
        method: 'GET',
        headers: {
          Authorization: 'Bearer ' + global.session.access_token,
        },
      })
        .then(stdInfoResponse => stdInfoResponse.text())
        .then(stdInfoResponseTxt => {
          context.setState({spinner: false});
          console.log('DEBUG: Passcode reset success. ', stdInfoResponseTxt);
          jsonUserData.passcodeResetComplete = true;
          DefaultPreference.set('user_data', JSON.stringify(jsonUserData)).then(
            function() {
              console.log(
                'DEBUG: Passcode user_data Updated to .',
                jsonUserData,
              );
              navigation.navigate('MyIdScreen');
            },
          );
        })
        .catch(error => {
          context.setState({spinner: false});
          console.log('DEBUG:  Password reset request failed.', error);
          showMessage({
            message: 'Error',
            description:
              'Unknown server error. Please check your internet connection. Contact support if issue prevails.',
            type: 'danger',
          });
        });
    });
  }
  changeLoginSignUpState() {
    if (this.state.loginsignupstate == 1) {
      this.setState({loginsignupstate: 2});
    } else {
      this.setState({loginsignupstate: 1});
    }
  }

  render() {
    return (
      <KeyboardAvoidingView
                behavior={Platform.OS === "ios" ? "padding" : null}
                style={{ flex: 1 }} >						 
      <SafeAreaView style={{flex: 1}}>
        <Spinner visible={this.state.spinner} textContent={'Loading...'} />
        <ScrollView>
          <ImageBackground
            style={{height: wp('70%'), width: wp('100%'), marginTop: -wp('7%')}}
            source={require('../../../images/top_bg_purple.png')}>
            <View style={{alignItems: 'center', marginTop: wp('15%')}}>
              <Text
                style={{
                  fontSize: wp('10%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Evolution Australia
              </Text>
              <Text
                style={{
                  fontSize: wp('8%'),
                  color: 'white',
                  fontWeight: 'bold',
                }}>
                Set Your Pass code
              </Text>
            </View>
          </ImageBackground>

          {/* main view */}
          <View style={{marginLeft: wp('5%'), marginRight: wp('5%')}}>
            <View
              style={{
                marginTop: wp('5%'),
                marginBottom: wp('5%'),
                alignItems: 'center',
              }}>
              <Text>Please set your passcode for set easy login</Text>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                Passcode
              </Text>
              <View style={styles.email}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon2.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => this.setState({password: text})}
                  inlineImageLeft="username"
                  inlineImagePadding={2}
                  keyboardType="numeric"
                  secureTextEntry={true}
                  maxLength={6}
                />
              </View>
            </View>

            <View style={{marginTop: wp('5%')}}>
              <Text style={{fontSize: wp('3.5%'), color: '#841c7c'}}>
                Confirm Passcode
              </Text>
              <View style={styles.password}>
                <Image
                  style={{marginRight: wp('4%'), marginLeft: wp('2%')}}
                  source={require('../../../images/icon2.png')}
                />
                <TextInput
                  style={{
                    height: 40,
                    width: wp('100%'),
                    borderColor: '#841c7c',
                    borderBottomWidth: 0,
                  }}
                  onChangeText={text => this.setState({password_confirm: text})}
                  inlineImageLeft="username"
                  secureTextEntry={true}
                  keyboardType="numeric"
                  inlineImagePadding={2}
                />
              </View>
            </View>

            <View style={{alignItems: 'center', paddingTop: wp('10%')}}>
              <Buttons
                text="Set Passcode"
                btnfontSize={wp('5%')}
                btnbackgroundColor="#841c7c"
                btntxtncolor="#ffffff"
                btnMarginRight={imageWidth / 20}
                btnMarginLeft={imageWidth / 20}
                onPress={this.onPressPasswordReset.bind(this)}
              />
            </View>

            {/* <View style={{alignItems:'center',paddingTop:wp('5%'),paddingBottom:wp('5%')}}>
              <Text style={{color:'#ff5d05',fontSize:wp('5%')}}>Sign Up</Text>
            </View> */}
          </View>
        </ScrollView>
      </SafeAreaView>
      </KeyboardAvoidingView>		 
    );
  }
}

export default LoginSignup;
