/* eslint-disable no-alert */
/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eqeqeq */
/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  Dimensions,
  ImageBackground,
  SafeAreaView,
  Alert,
  Modal,
  Button,
  TouchableOpacity,
  Linking,
} from 'react-native';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import DefaultPreference from 'react-native-default-preference';
import styles from './styles';
import Buttons from '../../uiElements/Buttons/RoundButtons';

import Loading from '../../uiElements/Loading';
const imageWidth = Dimensions.get('window').width;
import FlashMessage from 'react-native-flash-message';
import {showMessage, hideMessage} from 'react-native-flash-message';
import deviceInfoModule from 'react-native-device-info';

// const imageWidth = Dimensions.get('window').width;

// const handleInvitationToChannel = ({ params: { channelId } }) => ({ dispatch }) => {
//   // addCurrentUserToChannel is a redux-thunk action,
//   // which was defined somewhere in the code.
//   dispatch(addCurrentUserToChannel(channelId));
// }

// const schemes = [
//   {
//       name: 'https:',
//       routes: [
//           {
//               expression: '/m.youtube.com/:channelId',
//               callback: handleInvitationToChannel
//           }
//       ]
//   }
// ];

//const App = createDeepLinkingHandler(schemes)(AppComponent);

//const withDeepLinking = createDeepLinkingHandler(schemes);
class StartScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Alert_Visibility: false,
      response: {},
    };
  }

  btnPress() {
    //this.props.navigation.navigate('ResetPassword')
    var navigation = this.props.navigation;
    // DefaultPreference.clear('user_data')
    //  alert(imageWidth)
    DefaultPreference.get('user_data').then(function(value) {
      console.log('DEBUG: Device ID is : ', value);
      if (value) {
        let jsonData = JSON.parse(value);
        if (jsonData.passcodeResetComplete != undefined) {
          console.log('passcode login');
          navigation.navigate('PasscodeLogin');
        } else {
          navigation.navigate('LoginScreen');
        }
      } else {
        navigation.navigate('LoginScreen');
      }
    });
  }

  componentDidMount() {
    Linking.addEventListener('url', this.handleOpenURL);
  }
  componentWillUnmount() {
    Linking.removeEventListener('url', this.handleOpenURL);
  }
  // getSecondPart(str){
  //   return str.split('=')[1];
  // }
  handleOpenURL(event) {
    console.log(event.url);
    const route = event.url.replace(/.*?:\/\//g, '');
    console.log(route);
    alert(route.split('=')[1]);
    if (route.split('=')[1] != '') {
      this.props.dispatch(resetPasswordValidate(route.split('=')[1]));
    }

    // do something with the url, in our case navigate(route)
  }

  render() {
    return (
      <SafeAreaView style={styles.wrapper}>
        <View style={{flex: 1, alignItems: 'center', marginTop: hp('5%')}}>
          {/* <Image
               style={styles.stretch}
                source={require('../../images/spotonmoneylogo.png')}
           />
            */}
        </View>

        <View style={{flex: 6, alignItems: 'center'}}>
          <View style={styles.text1}>
            <Text style={styles.text1style}>
              Evolution Hospitality Institute
            </Text>
          </View>

          <View style={styles.text2}>
            <Image
              style={{width: 200, height: 200}}
              source={require('../../../images/nav.png')}
            />
          </View>

          <View style={styles.text2}>
            <Text style={styles.textdisplay}>
              {' '}
              Bringing 5-star Education to the Hospitality Industry
            </Text>
          </View>
          <View>
            <Text style={styles.textdisplay}>
              {deviceInfoModule.getVersion()}
            </Text>
          </View>
        </View>

        <View
          style={{
            flex: 1,
            marginBottom: imageWidth / 10,
            alignItems: 'center',
          }}>
          <Buttons
            text="Login"
            btnfontSize={wp('5%')}
            btnbackgroundColor="#841c7c"
            btntxtncolor="#ffffff"
            btnMarginRight={imageWidth / 12}
            btnMarginLeft={imageWidth / 12}
            onPress={() => this.btnPress()}
          />
        </View>
      </SafeAreaView>
    );
  }
}

export default StartScreen;
