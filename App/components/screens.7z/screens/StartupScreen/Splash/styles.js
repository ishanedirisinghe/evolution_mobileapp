
import EStyleSheet from 'react-native-extended-stylesheet';
import {Dimensions} from 'react-native';
const imageWidth = Dimensions.get('window').width;
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
EStyleSheet.build({$rem: imageWidth / 380});

export default EStyleSheet.create({
  wrapper: {
    flex: 5,
    backgroundColor:'#ffffff'
  },
  text1:{
      paddingBottom:hp('6%'),
      alignItems: 'center',
  },
  text2:{
    alignItems: 'center',
    padding:wp('5%')
  },
  text1style:{
    fontSize:hp('4%'),
    color:'#841c7c',
    fontWeight:'bold',
    textAlign: 'center', 
    
  },
  textdisplay:{
    color:'#841c7c',
    fontSize:hp('3%'),
    textAlign: 'center', 
  },

commonTextStyle:{
  color:'#841c7c',
}
,
  Alert_Main_View:{
 
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor : "#20366B", 
    height: hp('50%') ,
    width: wp('90%'),
    borderWidth: 1,
    borderColor: '#fff',
    borderRadius:7,
   
  },
   
  Alert_Title:{
   
    fontSize: 25, 
    color: "#fff",
    textAlign: 'center',
    padding: 10,
    height: '28%'
   
  },
   
  Alert_Message:{
   
      fontSize: 22, 
      color: "#fff",
      textAlign: 'center',
      padding: 10,
      height: '42%'
     
    },
   
  buttonStyle: {
      
      width: wp('60%'),
      height: hp('100%'),
      justifyContent: 'center',
      alignItems: 'center'
   
  },
     
  TextStyle:{
      color:'#fff',
      textAlign:'center',
      fontSize: hp('3%'),
    
  }
  
});