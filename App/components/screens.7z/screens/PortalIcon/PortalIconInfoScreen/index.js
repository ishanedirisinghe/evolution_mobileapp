import React, { Component } from 'react';
import {
    View, Text,
    Image,
    ActivityIndicator,
    Dimensions,
    SafeAreaView,
    ScrollView,
    FlatList,
    TouchableOpacity

} from 'react-native';
import { WebView } from 'react-native-webview';

import Spinner from 'react-native-loading-spinner-overlay';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';


const imageWidth = Dimensions.get('window').width;
import NavBarWithBack from '../../uiElements/NavBarWithBack';

import style from './styles';

// const imageWidth = Dimensions.get('window').width;
class Search extends Component {
    fieldRef = React.createRef();

    constructor(props) {
        super(props);
        this.state = {
            spinner: false,
        }
    };

    componentDidMount() {
        const { WEB_URL } = this.props.navigation.state.params;
        const { TITLE } = this.props.navigation.state.params;
        this.setState({ web_url: WEB_URL, title: TITLE })
      }

    showSpinner() {
        console.log('Show Spinner');
        this.setState({ spinner: true });
    }

    hideSpinner() {
        console.log('Hide Spinner');
        this.setState({ spinner: false });
    }

    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <NavBarWithBack name={this.state.title} onPressBack={() => this.props.navigation.goBack() } />
                <View style={{ flex: 1 }}>
                    <Spinner visible={this.state.spinner} textContent={'Loading...'} />
                    <WebView
                        ref="webview"
                        style={{ width: '100%', height: "100%" }}
                        source={{ uri: this.state.web_url }}
                        onLoadStart={() => (this.showSpinner())}
                        onLoad={() => (this.hideSpinner())}
                        //onNavigationStateChange={this._onURLChanged.bind(this)} 
                        // onMessage={(event) => { this.onMessage(event) }}
                        javaScriptEnabled={true}
                        domStorageEnabled={true}
                        injectedJavaScript={this.state.cookie}
                        startInLoadingState={false}
                        useWebKit={true}
                    />

                </View>
            </SafeAreaView>
        );
    }
}

export default Search;