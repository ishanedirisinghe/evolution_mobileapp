/* eslint-disable react-native/no-inline-styles */
/* eslint-disable no-unused-vars */
import React, {Component, useCallback} from 'react';
import {
  View,
  Text,
  Image,
  ActivityIndicator,
  Dimensions,
  SafeAreaView,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Linking,
  Button,
} from 'react-native';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import QRCode from 'react-native-qrcode-svg';
import Buttons from '../../uiElements/Buttons/RoundButtons';
import FlashMessage from 'react-native-flash-message';
import {showMessage, hideMessage} from 'react-native-flash-message';
import DefaultPreference from 'react-native-default-preference';
const imageWidth = Dimensions.get('window').width;
import NavBar from '../../uiElements/NavBar';
import ImagePicker from 'react-native-image-crop-picker';
import Icon from 'react-native-vector-icons/FontAwesome';
//import Loading from '../../../uiElements/Loading';

import Spinner from 'react-native-loading-spinner-overlay';

import styles from './styles';

//const imageWidth = Dimensions.get('window').width;
class Search extends Component {
  fieldRef = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      isLogged: false,
      visible: true,
    };
  }

  // static getDerivedStateFromProps(props, state) {

  // }

  render() {
    return (
      <SafeAreaView style={{flex: 1}}>
        <NavBar
          name={'Portal Icons'}
          onPressBurger={() => this.props.navigation.openDrawer()}
        />
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          {/* <QRCode
      value="http://awesome.link.qr"
      size={200}
      logoBackgroundColor='transparent'
    /> */}
          <View style={{alignItems: 'center', paddingTop: wp('5%')}}>
            <Icon.Button
              style={{
                marginLeft: 1,
                width: 175,
                height: 50,
                borderRadius: 1,
              }}
              name="address-book"
              btnfontSize={wp('5%')}
              backgroundColor="#841c7c"
              btnMarginRight={imageWidth / 20}
              btnMarginLeft={imageWidth / 20}
              size={40}
              onPress={() => {
                Linking.openURL('https://lms.evolution.pageculinaire.com.au');
              }}>
              Learning Portal
            </Icon.Button>
          </View>
          <View style={{alignItems: 'center', paddingTop: wp('5%')}}>
            <Icon.Button
              style={{
                marginLeft: 1,
                width: 175,
                height: 50,
                borderRadius: 1,
              }}
              name="graduation-cap"
              btnfontSize={wp('5%')}
              backgroundColor="#841c7c"
              btnMarginRight={imageWidth / 20}
              btnMarginLeft={imageWidth / 20}
              size={40}
              onPress={() => {
                Linking.openURL('https://admin.axcelerate.com.au/learner/');
              }}>
              Student Portal
            </Icon.Button>
          </View>
          <View style={{alignItems: 'center', paddingTop: wp('5%')}}>
            <Icon.Button
              style={{
                marginLeft: 1,
                width: 175,
                height: 50,
                borderRadius: 1,
              }}
              name="envelope"
              btnfontSize={wp('5%')}
              backgroundColor="#841c7c"
              btnMarginRight={imageWidth / 20}
              btnMarginLeft={imageWidth / 20}
              size={40}
              onPress={() => {
                Linking.openURL('https://outlook.office365.com');
              }}>
              Student Email
            </Icon.Button>
          </View>
          <View style={{alignItems: 'center', paddingTop: wp('5%')}}>
            <Icon.Button
              style={{
                marginLeft: 1,
                width: 175,
                height: 50,
                borderRadius: 1,
              }}
              name="book"
              btnfontSize={wp('5%')}
              backgroundColor="#841c7c"
              btnMarginRight={imageWidth / 20}
              btnMarginLeft={imageWidth / 20}
              size={40}
              onPress={() => {
                Linking.openURL(
                  'https://lms.evolution.pageculinaire.com.au/mypassport',
                );
              }}>
              My Passport
            </Icon.Button>
          </View>
          <View style={{alignItems: 'center', paddingTop: wp('5%')}} />
        </View>
      </SafeAreaView>
    );
  }
}

// const mapStateToProps = state =>({
//   loginsuccessEmail:state.startUpReducer.loginsuccessEmail,
//   loading:state.startUpReducer.loading,
//   accesstoken:state.startUpReducer.accesstoken

// });

export default Search;
