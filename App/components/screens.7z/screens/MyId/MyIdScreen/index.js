/* eslint-disable react-native/no-inline-styles */
/* eslint-disable consistent-this */
/* eslint-disable no-undef */

import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  Dimensions,
  SafeAreaView,
  ScrollView,
} from 'react-native';

import {widthPercentageToDP as wp} from 'react-native-responsive-screen';
import Barcode from 'react-native-barcode-builder';
//import Moment from 'moment';
import NavBar from '../../uiElements/NavBar';

//import Loading from '../../../uiElements/Loading';

import styles from './styles';

const fWidth = Dimensions.get('window').width;

class Search extends Component {
  fieldRef = React.createRef();

  constructor(props) {
    super(props);
    this.state = {
      isLogged: false,
      visible: true,
      firstName: '',
      lastName: '',
      mobile: '',
      barcode: '1',
      profileImageUrl: '',
      isBarCodeHidden: true,
      studentId: '',
      email: '',
      DateOfExpire: '',
      relCount: 0,
      IsExpire: false,
      IsInactive: false,
    };
  }
  componentDidMount() {
    this.updateData();
    this.props.navigation.addListener('didFocus', () => {
      this.updateData();
    });
  }
  updateData() {
    var context = this;
    this.setState({relCount: 1});
    const user_data = this.props.navigation.getParam('user_data', false);
    context.setState({spinner: true});
    if (user_data) {
      let resultJson = JSON.parse(user_data);
      this.setState({firstName: resultJson.FirstName});
      this.setState({lastName: resultJson.LastName});
      this.setState({mobile: resultJson.Phone});
      this.setState({barcode: resultJson.StudentID});
      this.setState({profileImageUrl: resultJson.ImageUrl});
      this.setState({isBarCodeHidden: false});
      this.setState({studentId: resultJson.StudentID});
      this.setState({email: resultJson.eMail});
      console.log('DEBUG: MyID navigation data received', resultJson);
      context.setState({spinner: false});
      this.setState({email: resultJson.eMail});
      this.setState({IsExpire: resultJson.IsExpire});
      this.setState({IsInactive: resultJson.IsInactive});
      this.setState({DateOfExpire: resultJson.sDateOfExpire});
    } else {
      context.setState({spinner: true});
      let requestPath = global.API_ENDPOINT + '/api/StudentAPI/GetStudentInfo';
      console.log('DEBUG: GetStudentInfo', requestPath);
      fetch(requestPath, {
        method: 'GET',
        headers: {
          Authorization: 'Bearer ' + global.session.access_token,
        },
      })
        .then(response => response.text())
        .then(result => {
          context.setState({spinner: false});
          console.log('DEBUG: GetStudentInfo request success. ', result);
          let resultJson = JSON.parse(result);
          this.setState({firstName: resultJson.FirstName});
          this.setState({lastName: resultJson.LastName});
          this.setState({mobile: resultJson.Phone});
          this.setState({barcode: resultJson.StudentID});
          this.setState({profileImageUrl: resultJson.ImageUrl});
          this.setState({isBarCodeHidden: false});
          this.setState({studentId: resultJson.StudentID});
          this.setState({email: resultJson.eMail});
          this.setState({IsExpire: resultJson.IsExpire});
          this.setState({IsInactive: resultJson.IsInactive});
          this.setState({DateOfExpire: resultJson.sDateOfExpire});
        })
        .catch(error => {
          context.setState({spinner: false});
          console.log('DEBUG: GetStudentInfo request failed.', error);
          showMessage({
            message: 'Error',
            description:
              'Unknown server error. Please check your internet connection. Contact support if issue prevails.',
            type: 'danger',
          });
        });
    }
  }

  render() {
    return (
      <SafeAreaView style={{flex: 1}}>
        <NavBar
          name={'MY ID'}
          onPressBurger={() => this.props.navigation.openDrawer()}
        />
        <ScrollView>
          {this.state.IsExpire && (
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                paddingTop: wp('6%'),
              }}>
              <View style={{}}>
                <Text
                  style={{
                    color: 'white',
                    fontSize: wp('10%'),
                    backgroundColor: '#ff0057',
                    alignSelf: 'stretch',
                    textAlign: 'center',
                    width: fWidth,
                  }}>
                  EXPIRED!
                </Text>
              </View>
            </View>
          )}
          {this.state.IsInactive && (
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                paddingTop: wp('6%'),
              }}>
              <View style={{}}>
                <Text
                  style={{
                    color: 'white',
                    fontSize: wp('10%'),
                    backgroundColor: '#ff0057',
                    alignSelf: 'stretch',
                    textAlign: 'center',
                    width: fWidth,
                  }}>
                  DEACTIVATED!
                </Text>
              </View>
            </View>
          )}
          <View style={{}}>
            {/* <QRCode
      value="http://awesome.link.qr"
      size={200}
      logoBackgroundColor='transparent'
      source={{uri: this.state.profileDefault}}
      source={require('../../../images/face2.png')}
    /> */}

            <View style={{marginTop: wp('10%'), alignItems: 'center'}}>
              <Image
                style={styles.avatar}
                source={{uri: this.state.profileImageUrl}}
              />
            </View>
            <View style={{paddingLeft: wp('10%'), paddingRight: wp('10%')}}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  paddingTop: wp('6%'),
                }}>
                <View style={{}} />
              </View>
              <View style={{justifyContent: 'center'}}>
                <View style={{flexDirection: 'row', justifyContent: 'center'}}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      fontSize: wp('6%'),
                    }}>
                    {this.state.firstName}
                  </Text>
                </View>
                <View style={{flexDirection: 'row', justifyContent: 'center'}}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      fontSize: wp('6%'),
                    }}>
                    {this.state.lastName}
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  paddingTop: wp('2%'),
                }}>
                <View style={{}}>
                  <Text>Student ID:</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', justifyContent: 'center'}}>
                <View style={{}}>
                  <Text style={{fontWeight: 'bold', fontSize: wp('6%')}}>
                    {' '}
                    {this.state.studentId}
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  paddingTop: wp('2%'),
                }}>
                <View style={{}}>
                  <Text>E-Mail:</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', justifyContent: 'center'}}>
                <View style={{}}>
                  <Text style={{fontWeight: 'bold', fontSize: wp('6%')}}>
                    {' '}
                    {this.state.email}
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  paddingTop: wp('2%'),
                }}>
                <View style={{}}>
                  <Text>Phone:</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', justifyContent: 'center'}}>
                <View style={{}}>
                  <Text style={{fontWeight: 'bold', fontSize: wp('6%')}}>
                    {this.state.mobile}
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  paddingTop: wp('2%'),
                }}>
                <View style={{}}>
                  <Text>Expiry Date:</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', justifyContent: 'center'}}>
                <View style={{}}>
                  <Text style={{fontWeight: 'bold', fontSize: wp('6%')}}>
                    {this.state.DateOfExpire}
                  </Text>
                </View>
              </View>
              {!this.state.IsExpire && !this.state.IsInactive && (
                <View style={{marginTop: wp('4%'), alignItems: 'center'}}>
                  <Barcode
                    hide={this.state.isBarCodeHidden}
                    value={this.state.barcode}
                    format="CODE128"
                  />
                </View>
              )}
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }
}

// const mapStateToProps = state =>({
//   loginsuccessEmail:state.startUpReducer.loginsuccessEmail,
//   loading:state.startUpReducer.loading,
//   accesstoken:state.startUpReducer.accesstoken

// });

export default Search;
