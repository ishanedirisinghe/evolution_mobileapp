/* eslint-disable no-unused-vars */
import EStyleSheet from 'react-native-extended-stylesheet';
import {Dimensions} from 'react-native';
const imageWidth = Dimensions.get('window').width;
EStyleSheet.build({$rem: imageWidth / 380});
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

export default EStyleSheet.create({
  iteminterest: {
    height: wp('30%'),
    width: wp('45%'),
    borderRadius: 5,
  },
  iteminterest1: {
    flex: 1,
    paddingLeft: wp('3%'),
    paddingRight: wp('5%'),
  },
  avatar: {
    width: wp('50%'),
    height: wp('50%'),
    borderRadius: wp('20%'),
    borderWidth: 4,
    borderColor: 'white',
  },
});
